# InterpolDataFetch
This is a python developer task.
